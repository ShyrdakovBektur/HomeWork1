import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        String NAME = "Мираида";
        final int NUM = 101;
        String word = " розу";
        String Мираида = NUM + word;
        System.out.println(Мираида);
        System.out.println(NAME + " получила " + NUM + word + " на день рождения ");

        if (NUM < 0) {
            System.out.println("Вы сохранили отрецательное число");
        } else if (NUM > 0) {
            System.out.println("Вы сохранили положительное число");
        } else {
            System.out.println("Вы сохранили нуль");
        }



















    }
}